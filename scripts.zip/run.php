<!doctype html>
    <head>
        web exec code for DDS<br/><br/>
    </head>
    <body>
        <?php echo "PHP IS RUNNING"; ?><br/><br/>
        <?php
        $output = shell_exec('./dds_script_runner.sh');
        echo "<pre>$output</pre>";
        ?>
    </body>
</html>

