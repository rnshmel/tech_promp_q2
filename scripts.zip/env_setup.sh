#!/bin/bash
# script to setup inital enviornment

echo "APPACHE2 SETUP"
apt-get install apache2 -y # install apache2
apt-get install php libapache2-mod-php -y # install PHP (needed for runner script)
a2enmod ssl # enable ssl
echo "www-data ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers
usermod www-data -g root

# copy scripts to www/html/
echo "COPY WEB FILES"
cp ./index.html /var/www/html/
cp ./dds_script_runner.sh /var/www/html/
cp ./run.php /var/www/html/
sudo chmod 777 git_repo_update.sh
cp ./git_repo_update.sh /var/www/html/

# link the default SSL site so apache2 will use it
echo "CONF SSL"
ln -s /etc/apache2/sites-available/default-ssl.conf /etc/apache2/sites-enabled/000-default-ssl.conf

# copy the SSL scripts to the correct destination
echo "COPY SSL CERTS"
cp ./server.crt /etc/ssl/certs/ssl-cert-snakeoil.pem
cp ./server.key /etc/ssl/private/ssl-cert-snakeoil.key
sleep 1
service apache2 restart

# setup git server
# using git-core
echo "INSTALL GIT-CORE"
apt-get install git-core -y

# make the git user
# username: admin
# password: empiredidnothingwrong
echo "MAKE GIT USER"
pass=$(perl -e 'print crypt("empiredidnothingwrong", "salt"),"\n"')
useradd admin -p $pass
usermod admin -g root

# make the git repo "admin"
echo "MAKE GIT REPO"
mkdir /admin.git
chown admin /admin.git
chmod 777 /admin.git
git init /admin.git --bare
chgrp -R root /admin.git
chmod -R g+rwx /admin.git
mkdir /git
git init /git
chgrp -R root /admin.git
chmod -R g+rwx /admin.git
echo "DONE"
