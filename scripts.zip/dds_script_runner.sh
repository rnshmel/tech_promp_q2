#!/bin/bash

# this script loops through and runs all scripts in a given directory
# this script is run using the shell_exec php command
# output is amaglmated into a single variable

# set path
echo "--- SCRIPT START ---"
mypath="/git/"
echo "current path: "$mypath
echo ""

# run git_repo_update script
echo "pulling git repo"
echo ""
./git_repo_update.sh

# find all scripts in the path, assume scripts are named with a .sh convention
# scripts are extrated with a simple grep command
dir_cont=$(ls -l $mypath)
echo "all files in path"
echo "========================"
echo "${dir_cont}"
echo ""

# get only .sh files
# read into an array for ease of parsing
readarray -t dir_scripts <<< $(ls $mypath | grep -E "(.sh)")
echo "all scripts in path"
echo "========================"
for i in $dir_scripts
do
echo $i
sudo chmod 777 $mypath$i
done
echo ""

# run each script and echo the results
for i in $dir_scripts
do
echo "running "$i
echo "===================================="
$mypath$i
echo ""
done
