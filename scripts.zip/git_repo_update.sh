#!/bin/bash

cd /git
sudo git pull /admin.git
